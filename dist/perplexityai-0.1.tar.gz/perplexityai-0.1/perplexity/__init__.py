name: str = "perplexity"

from .utils import *
from .labs import Labs
from .perplexity import Perplexity